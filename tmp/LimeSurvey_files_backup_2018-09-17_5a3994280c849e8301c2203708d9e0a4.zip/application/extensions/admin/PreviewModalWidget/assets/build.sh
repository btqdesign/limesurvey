babel previewModalWidget.src.js --out-file previewModalWidget.dist.js
node-sass --output-style compressed previewModalWidget.src.scss > previewModalWidget.dist.css