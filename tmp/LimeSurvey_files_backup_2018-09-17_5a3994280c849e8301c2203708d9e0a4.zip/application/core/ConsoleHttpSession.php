<?php
class ConsoleHttpSession extends CHttpSession
{
    public function setCookieParams($value)
    {
        return;
    }
    public function setCookieMode($value)
    {
        return;
    }
}
